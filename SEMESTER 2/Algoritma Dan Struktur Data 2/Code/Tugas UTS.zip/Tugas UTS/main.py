from lib.doubleLinkedList import Node, DoubleLinkedList



list1 = DoubleLinkedList()

list1.initJSON('./db/data.json')

list1.menu()
# list1.addLast(1)
# list1.addLast(2)
# list1.addLast(3)
# list1.addLast(4)
# list1.addLast(5)
# list1.display()
# list1.displayReverse()
# list1.removeAll()
# list1.display()
# list1.displayReverse()