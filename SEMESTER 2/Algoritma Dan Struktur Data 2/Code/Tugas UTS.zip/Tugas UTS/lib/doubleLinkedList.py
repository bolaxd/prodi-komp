import json
from terminaltables import AsciiTable
from colorama import Fore, Style

class Node:
    def __init__(self, info):
        self.info = info
        self.prev = None
        self.next = None

class DoubleLinkedList:
    def __init__(self):
        self.awal = None
        self.akhir = None
        self.data = {}

    def initJSON(self, path):
        with open(path) as json_data:
            data = json.load(json_data)

            self.data = data
    
    def menu(self):
        string = f'''{Fore.WHITE}
# ============================================== #
#    {Fore.RED}        [  Aplikasi Data FILM  ]  {Fore.WHITE}          #
# ============================================== #

{Fore.YELLOW}\x1b[3mInfo : Terdapat {len(self.data)} film di database.\x1b[0m

{Fore.WHITE}1) {Fore.GREEN}Tambah data FILM
{Fore.WHITE}2) {Fore.GREEN}Edit data FILM
{Fore.WHITE}3) {Fore.GREEN}Hapus data FILM
{Fore.WHITE}4) {Fore.GREEN}Tampilkan FILM yang tersedia
{Fore.LIGHTBLACK_EX}--------------------------------
{Fore.WHITE}5) {Fore.CYAN}Tentang Aplikasi (Credit)
{Fore.WHITE}6) {Fore.RED}Keluar

{Fore.WHITE}[ Pilih Salah Satu ] >> '''

        opsi = input(string)

    def isEmpty(self):
        return self.awal is None

    def display(self):
        print("Data : ", end="")
        if self.isEmpty():
            print("[Data Kosong]")
        else:
            bantu = self.awal
            while bantu is not None:
                print(bantu.info, " ", end="")
                bantu = bantu.next
            print()
    def displayReverse(self):
        print("Data : ", end="")
        if self.isEmpty():
            print("[Data Kosong]")
        else:
            bantu = self.akhir
            while bantu is not None:
                print(bantu.info, " ", end="")
                bantu = bantu.prev
            print()
    def size(self):
        if self.isEmpty():
            banyakNode = 0
        else:
            bantu = self.awal
            banyakNode = 1
            while bantu.next is not None:
                banyakNode = banyakNode + 1
                bantu = bantu.next
        return banyakNode

    def getFirst(self):
        return self.awal

    def getLast(self):
        return self.akhir

    def get(self, index):
        if self.isEmpty() or index<1 or index>self.size():
            return None
        else:
            bantu = self.awal
            posisi = 1
            while posisi<index:
                bantu = bantu.next
                posisi = posisi + 1
            return bantu
    def addFirst(self, info):
        newNode = Node(info)
        if self.isEmpty():
            self.awal = newNode
            self.akhir = newNode
        else:
            newNode.next = self.awal
            self.awal.prev = newNode
            self.awal = newNode
    def addLast(self, info):
        newNode = Node(info)
        if self.isEmpty():
            self.awal = newNode
            self.akhir = newNode
        else:
            self.akhir.next = newNode
            newNode.prev = self.akhir
            self.akhir = newNode
    def add(self, info, index):
        if self.isEmpty() or index==1:
            self.addFirst(info)
        else:
            newNode = Node(info)
            nodeSisip = self.get(index)
            if nodeSisip is not None:
                newNode.prev = nodeSisip.prev
                newNode.next = nodeSisip
                nodeSisip.prev.next = newNode
                nodeSisip.prev = newNode
            else:
                print("Penyisipan",info,"gagal")

    def removeFirst(self):
        if self.isEmpty():
            print("Ngak bisa hapus. Data kosong")
        elif self.awal == self.akhir:
            removedNode = self.awal
            self.awal = None
            self.akhir = None
            del removedNode
        else: #jika data banyak
            removedNode = self.awal
            self.awal = self.awal.next
            self.awal.prev = None
            del removedNode
    def removeLast(self):
        if self.isEmpty():
            print("Ngak bisa hapus. Data kosong")
        elif self.awal == self.akhir:
            removedNode = self.awal
            self.awal = None
            self.akhir = None
            del removedNode
        else: #jika data banyak
            removedNode = self.akhir
            self.akhir = self.akhir.prev
            self.akhir.next = None
            del removedNode
    def remove(self, index):
        if self.isEmpty():
            print("Ngak bisa hapus. Data kosong")
        elif index==1:
            self.removeFirst()
        elif index==self.size():
            self.removeLast()
        else: # kalau ditengah-tengah
            removedNode = self.get(index)
            if removedNode is not None:
                removedNode.prev.next = removedNode.next
                removedNode.next.prev = removedNode.prev
                del removedNode
            else:
                print("Hapus gagal. Index tidak ditemukan")

    def removeAll(self):
        while self.isEmpty() == False:
            self.removeFirst()