<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
<center>
<h1>EDIT DATA BARANG</h1>
<hr>
<div class="col col-sm-5">
<table class="table">
<?php
// KONEKSI
$conn = mysqli_connect('localhost', 'root', '', 'IF4');
// INPUT
$kodebrg = $_POST['kodebrg'];
$namabarang = $_POST['namabarang'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];

$sqlAdd = "DELETE FROM barang WHERE kodebrg='$kodebrg'";
$hasilAdd = mysqli_query($conn, $sqlAdd);
echo "<div class='alert alert-success'>Data telah terhapus</div>";
// TAMPIL
// if (!mysqli_fetch_row($hasilTampil)) echo "<div class='alert alert-danger'>Data dengan Kode $kodebrg Tidak ditemukan!</div>";
    // Kode Tampil
    
echo "<tr>
        <td>KODE BARANG</td>
        <td><input readonly class='form-control' type='text' name='kodebrg' value='$kodebrg'></td>
    </tr>
        <tr>
        <td>NAMA BARANG</td>
        <td><input readonly class='form-control' type='text' name='namabarang' value='$namabarang'></td>
    </tr>
    <tr>
        <td>HARGA</td>
        <td><input readonly class='form-control' type='text' name='harga' value='$harga'></td>
    </tr>
    <tr>
        <td>STOK</td>
        <td><input readonly class='form-control' type='text' name='stok' value='$stok'></td>
    </tr>
</tr>";
?>
</table>
<hr>
<a class="btn btn-outline-warning" href="editbarang.html">Kembali</a>
</div>
