package latihan4;

/**
 *
 * @author Hanif
 */
public class Main {

    public static void main(String[] args) {
        // TODO code application logic here
        Tabungan saldo = new Tabungan(1000000, 2000000);
        saldo.tampilJudul();
        saldo.tampilHasil();
    }
    
}
