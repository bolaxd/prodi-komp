/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan2;

/**
 *
 * @author LAB05
 */
public interface Mobil {

    public abstract void tampilSpesifikasi();

    public abstract void start();

    public abstract void akselerasi();
}
