package co.gararetech.cinemas.controller;

import co.gararetech.cinemas.model.DashboardModel;

public class OrderTicketController {
    private DashboardModel model;

    public DashboardModel getModel() {
        return model;
    }

    public void setModel(DashboardModel model) {
        this.model = model;
    }
    
    public void showDetail(String movieId) {
        
    }
}
