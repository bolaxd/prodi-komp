# Cinema Booking App in Java

## Devs
- Edwin L.J
- Hanif A.S
- Ilmi F.G
- Eri S.
- Alfatih N.B

## Mockup
- https://www.figma.com/file/EIgAJHHpyIJgDkPIOgZWVW/Cinemas-App?node-id=0%3A1

### Task List

- [x] Splash Screen
- [x] Login
- [x] Register
- [x] Profile Page
- [x] Dashboard
- [x] Film Detail
- [ ] Checkout Ticket
- [ ] Booking Ticket
- [x] Upcoming
- [ ] Order History
- [x] Cinema Site List
- [x] Cinema Detail
