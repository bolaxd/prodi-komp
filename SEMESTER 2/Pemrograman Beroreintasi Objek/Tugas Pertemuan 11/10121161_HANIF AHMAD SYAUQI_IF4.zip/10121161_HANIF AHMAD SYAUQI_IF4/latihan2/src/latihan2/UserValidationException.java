package latihan2;

public class UserValidationException extends Exception{

    public UserValidationException(String message) {
        super(message);
    }
    
}
