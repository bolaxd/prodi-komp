package tugas2.hanif.pbo.event;

import tugas2.hanif.pbo.model.LoginFormModel;

public interface LoginFormListener {
    public void onChange(LoginFormModel model);
}
