/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package latihan1;

/**
 *
 * @author user
 */
public class Latihan1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Biodata Diri");
        System.out.println("-------------------------------------------");
        System.out.println("NAMA            : Hanif Ahmad Syauqi");
        System.out.println("ALAMAT          : Cimaung, Jagabaya");
        System.out.println("TEMPAT LAHIR    : Bandung");
        System.out.println("TANGGAL LAHIR   : 30 Juni 2003");
        System.out.println("-------------------------------------------");
        System.out.println("HOBI            : Coding, Main badminton, Hiking");
        System.out.println("MAKANAN FAVORIT : GULE, PECEL LELE, SATE");
    }
    
}
